This folder consists of a data file in csv format, data dictionary and metadata document.

Data file has 15-minute interval data from 25 homes of New York region. Right now this has only 6-months of data with 100% completeness. 

Data Dictionary gives a good description of columns present in the data file. 

Metadata document has other useful information on homes such as what circuits are configured in a home, when did we start collecting data etc.

If you have any more questions, please email us at dataport@pecanstreet.org.