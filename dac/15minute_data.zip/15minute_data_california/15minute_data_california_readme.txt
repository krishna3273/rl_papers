This folder consists of a data file in csv format, data dictionary and metadata document.

Data file has 15-minute interval data from 23 homes of California region. This has 1-year of data with 99% completeness. 

Data Dictionary gives a good description of columns present in the data file. 

Metadata document has other useful information on homes such as what circuits are configured in a home, when did we start collecting data etc.

If you have any more questions, please email us at dataport@pecanstreet.org.
